from django.contrib import admin
from .models import *


# Register your models here.
admin.site.register(Logo)
admin.site.register(Carusel)
admin.site.register(Carusel_main)
admin.site.register(Lavita_p)
admin.site.register(Course_year)
admin.site.register(Course_category)
admin.site.register(Course)
admin.site.register(Exam)
admin.site.register(Event)
admin.site.register(New)
admin.site.register(Service_photo)
admin.site.register(Service_text)
admin.site.register(Exem_text)
admin.site.register(Exem_text_3)
admin.site.register(Exem_level)
admin.site.register(Exem_photo)
admin.site.register(Work_day)
admin.site.register(Grafic)
admin.site.register(Phone)
admin.site.register(Email)
admin.site.register(Teachers)
admin.site.register(Students)


